// File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import { buildHeaders } from "../../../internal/headers.mjs";
import { path } from "../../../internal/utils/path.mjs";
function resolveResourceRequestOptions(options, buildOptions) {
    return Promise.resolve(options).then(buildOptions);
}
export class Content extends APIResource {
    /**
     * Download a skill version zip bundle.
     */
    retrieve(version, params, options) {
        const { skill_id } = params;
        return this._client.get(path `/skills/${skill_id}/versions/${version}/content`, resolveResourceRequestOptions(options, (options) => ({
            ...options,
            headers: buildHeaders([{ Accept: 'application/binary' }, options?.headers]),
            __security: { bearerAuth: true },
            __binaryResponse: true,
        })));
    }
}
//# sourceMappingURL=content.mjs.map